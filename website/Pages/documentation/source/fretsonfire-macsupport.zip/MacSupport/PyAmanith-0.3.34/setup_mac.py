# -*- encoding: iso-8859-1 -*-

from distutils.core import setup, Extension
from distutils.command.build_ext import build_ext as _build_ext
import shutil
import os
from os.path import join

try:
  amanith_base = os.environ["AMANITHDIR"]
except:
  amanith_base = "../amanith"

glew_base = "../glew"

debug = False
libs = ["amanith", "GLEW"]
inc = [join("changes", "include"), join(amanith_base, "include"), "include"]
inc += [join(glew_base, "include")]
lib = [join(amanith_base, "lib")]
lib += [join(glew_base, "lib")]
cc_args = []
swig_args = ["-Ibuild/amanith"]

if os.name == "nt":
  if debug:
    cc_args += ["/MDd"]
  else:
    cc_args += ["/MD"]
else:
  cc_args += ["-Wall"]
  if debug: cc_args += ["-g"]
  libs += ["stdc++"]

link_args = ["-framework OpenGL"]
link_args += ["-framework AGL"]
### link_args += ["-framework ZeroLink"]

class build_ext(_build_ext):
  """Custom extension builder command"""
  def copy(self, source, target, extension = ".swig.h"):
    """Copy the modified headers into the amanith source tree."""
    for root, dirs, files in os.walk(source):
      for file in files:
        if not file.endswith(extension): continue
        relPath = join(root, file).replace(source + os.sep, "")
        shutil.copy(join(source, relPath), join(target, relPath))
        print 'copied ' + join(source, relPath) + ' to ' + join(target, relPath)
  
  def run(self):
    # Ultimately this should use patch(1) or something, but for now
    # we just copy the stuff over.
    if not os.path.isdir(join("build", "amanith")):
      os.makedirs(join("build", "amanith"))
      shutil.copytree(join(amanith_base, "include"), join("build", "amanith", "include"))
    self.copy("changes", join("build", "amanith"))
    _build_ext.run(self)

ext_amanith = Extension('_amanith', ['amanith.i'],
                        include_dirs = inc,
                        library_dirs = lib,
                        libraries = libs,
                        extra_compile_args = cc_args,
                        extra_link_args = link_args)
                        
setup(name = 'PyAmanith',
      version = '0.3.34',
      author = "Sami Ky�stil�",
      author_email = "skyostil at kempele.fi",
      url = "http://kempele.fi/~skyostil",
      description = "Python wrapper for the Amanith 2D vector graphics library",
      py_modules = ["amanith"],
      ext_modules = [ext_amanith],
      cmdclass = {"build_ext": build_ext}
      )
