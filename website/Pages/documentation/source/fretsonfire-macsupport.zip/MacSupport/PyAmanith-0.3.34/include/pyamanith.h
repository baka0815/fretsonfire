/**
 *  This file is included in the generated wrapper.
 */

#ifndef PYAMANITH_H
#define PYAMANITH_H

/* TODO: parse this from the configuration file */
//#define DOUBLE_REAL_TYPE
#if defined(DOUBLE_REAL_TYPE)
#   error Compile Amanith with floats for better performance
#endif

#include <amanith/1d/gbeziercurve1d.h>
#include <amanith/1d/gbsplinecurve1d.swig.h>
#include <amanith/1d/gcurve1d.h>
#include <amanith/1d/ghermitecurve1d.h>
#include <amanith/1d/gmulticurve1d.h>
#include <amanith/1d/gpolylinecurve1d.h>
#include <amanith/2d/ganimtrsnode2d.h>
#include <amanith/2d/gbeziercurve2d.h>
#include <amanith/2d/gbsplinecurve2d.h>
#include <amanith/2d/gcurve2d.h>
#include <amanith/2d/gellipsecurve2d.h>
#include <amanith/2d/gfont2d.h>
#include <amanith/2d/ghermitecurve2d.h>
#include <amanith/2d/gmesh2d.h>
#include <amanith/2d/gmulticurve2d.h>
#include <amanith/2d/gpath2d.h>
#include <amanith/2d/gpixelmap.h>
#include <amanith/2d/gpolylinecurve2d.h>
#include <amanith/2d/gtesselator2d.h>
#include <amanith/2d/gtracer2d.h>
#include <amanith/gclassid.h>
#include <amanith/gelement.h>
#include <amanith/geometry/gaabox.h>
#include <amanith/geometry/gaffineparts.h>
#include <amanith/geometry/garea.h>
//#include <amanith/geometry/gaxisangle.h>
#include <amanith/geometry/gaxisangle.swig.h>
#include <amanith/geometry/gdistance.h>
#include <amanith/geometry/gintersect.h>
#include <amanith/geometry/ginterval.h>
#include <amanith/geometry/glineseg.h>
#include <amanith/geometry/gmatrix.h>
#include <amanith/geometry/goobox.h>
#include <amanith/geometry/gplane.h>
//#include <amanith/geometry/gquat.h>
#include <amanith/geometry/gquat.swig.h>
#include <amanith/geometry/gray.h>
#include <amanith/geometry/gsphere.h>
#include <amanith/geometry/gvect.h>
#include <amanith/geometry/gxform.h>
#include <amanith/geometry/gxformconv.h>
#include <amanith/gerror.h>
#include <amanith/gglobal.h>
#include <amanith/gimpexp.h>
#include <amanith/gkernel.h>
#include <amanith/gmath.h>
#include <amanith/gmultiproperty.h>
#include <amanith/gopenglext.h>
#include <amanith/gpluglib.h>
#include <amanith/gproperty.h>
#include <amanith/numerics/geigen.h>
#include <amanith/numerics/gfilter.h>
#include <amanith/numerics/gintegration.h>
//#include <amanith/rendering/gdrawboard.h>
#include <amanith/rendering/gdrawboard.swig.h>
#include <amanith/rendering/gdrawstyle.h>
#include <amanith/rendering/gopenglboard.h>
#include <amanith/support/gavltree.h>
#include <amanith/support/gmetaprogramming.h>
#include <amanith/support/gsvgpathtokenizer.h>
#include <amanith/support/gutilities.h>

using namespace Amanith;

#endif
